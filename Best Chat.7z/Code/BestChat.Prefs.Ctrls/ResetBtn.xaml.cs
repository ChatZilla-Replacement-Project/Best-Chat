﻿namespace BestChat.Prefs.Ctrls
{
	/// <summary>
	/// Interaction logic for ResetBtn.xaml
	/// </summary>
	public partial class ResetBtn : System.Windows.Controls.Button
	{
		public ResetBtn() => InitializeComponent();
	}
}