﻿// Ignore Spelling: Prefs Ctrls

namespace BestChat.Prefs.Ctrls
{
	/// <summary>
	/// Interaction logic for InfoOnThisPageTextBlock.xaml
	/// </summary>
	public partial class InfoOnThisPageTextBlock : System.Windows.Controls.TextBlock
	{
		public InfoOnThisPageTextBlock() => InitializeComponent();
	}
}