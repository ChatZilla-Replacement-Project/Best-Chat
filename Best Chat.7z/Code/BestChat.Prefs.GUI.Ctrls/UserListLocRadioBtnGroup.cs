﻿// Ignore Spelling: Prefs Ctrls Loc

namespace BestChat.Prefs.GUI.Ctrls
{
	public class UserListLocRadioBtnGroup : BestChat.GUI.Ctrls.EnumRadioBtnGroup<Data.Prefs.GlobalPrefs.AppearancePrefs.UserListPrefs
		.Location>
	{
	}
}