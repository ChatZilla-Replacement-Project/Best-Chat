﻿// Ignore Spelling: Prefs Ctrls

namespace BestChat.Prefs.GUI.Ctrls
{
	/// <summary>
	/// Interaction logic for ResetBtn.xaml
	/// </summary>
	public partial class ResetBtn : System.Windows.Controls.Button
	{
		public ResetBtn() => InitializeComponent();
	}
}