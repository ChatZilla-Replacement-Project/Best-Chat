﻿// Ignore Spelling: Prefs Ctrls

namespace BestChat.Prefs.GUI.Ctrls
{
	public class UserListWaysToShowModesRadioBtnGroup : BestChat.GUI.Ctrls.EnumRadioBtnGroup<Data.Prefs.GlobalPrefs.AppearancePrefs
		.UserListPrefs.WaysToShowModes>
	{
	}
}