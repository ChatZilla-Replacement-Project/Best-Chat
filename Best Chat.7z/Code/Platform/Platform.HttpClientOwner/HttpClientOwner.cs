﻿namespace BestChat.Platform.HttpClientOwner
{
	public static class HttpClientOwner
	{
		public static readonly System.Net.Http.HttpClient hc = new();
	}
}