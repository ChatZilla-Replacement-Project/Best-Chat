﻿// Ignore Spelling: Inline

namespace BestChat.Platform.Conversations.PlaceHolder
{
	public interface IInlinePlaceHolder
	{
		string AsText
		{
			get;
		}
	}
}