﻿// Ignore Spelling: Ctrls Ctrl

namespace BestChat.GUI.Ctrls
{
	/// <summary>
	/// Interaction logic for FileBrowserCtrl.xaml
	/// </summary>
	public partial class FileBrowserCtrl : System.Windows.Controls.UserControl
	{
		public FileBrowserCtrl()
		{
			InitializeComponent();
		}
	}
}