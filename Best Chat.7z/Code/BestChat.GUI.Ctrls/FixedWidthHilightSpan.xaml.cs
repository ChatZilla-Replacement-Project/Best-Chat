﻿// Ignore Spelling: Hilight Ctrls

namespace Best_Chat.Ctrls
{
	/// <summary>
	/// Interaction logic for FixedWidthHilightSpan.xaml
	/// </summary>
	public partial class FixedWidthHilightSpan : System.Windows.Documents.Span
	{
		public FixedWidthHilightSpan() => InitializeComponent();
	}
}