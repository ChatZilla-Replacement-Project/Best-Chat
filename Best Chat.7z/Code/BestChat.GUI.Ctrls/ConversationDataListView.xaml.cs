﻿// Ignore Spelling: Ctrls

namespace BestChat.GUI.Ctrls
{
	/// <summary>
	/// Interaction logic for ConversationDataTemplates.xaml
	/// </summary>
	public partial class ConversationDataListView : System.Windows.Controls.ListView
	{
		#region Constructors & Deconstructors
			public ConversationDataListView() => InitializeComponent();
		#endregion
	}
}