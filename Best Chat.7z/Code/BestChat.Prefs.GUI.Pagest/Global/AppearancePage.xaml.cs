// Ignore Spelling: Prefs Ctrls

namespace BestChat.Prefs.GUI.Pages.Global
{
	/// <summary>
	/// Interaction logic for Global.xaml
	/// </summary>
	public partial class AppearancePage : System.Windows.Controls.UserControl
	{
		#region Constructors & Deconstructors
			public AppearancePage()
			{
				InitializeComponent();
			}
		#endregion

		#region Delegates
		#endregion

		#region Events
		#endregion

		#region Constants
		#endregion

		#region Helper Types
		#endregion

		#region Members
		#endregion

		#region Properties
		#endregion

		#region Methods
		#endregion

		#region Event Handlers
		#endregion
	}
}