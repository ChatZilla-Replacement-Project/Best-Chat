﻿namespace BestChat.IRC.Global.View
{
	/// <summary>
	/// Interaction logic for GlobalOptTab.xaml
	/// </summary>
	public partial class GlobalOptTab : System.Windows.Controls.UserControl
	{
		public GlobalOptTab()
		{
			InitializeComponent();
		}
	}
}