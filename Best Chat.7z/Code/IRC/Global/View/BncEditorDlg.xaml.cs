﻿namespace BestChat.IRC.Global.View
{
	/// <summary>
	/// Interaction logic for BncEditor.xaml
	/// </summary>
	public partial class BncEditorDlg : System.Windows.Window
	{
		#region Constructors & Deconstructors
			public BncEditorDlg()
			{
				InitializeComponent();
			}
		#endregion

		#region Delegates
		#endregion

		#region Events
		#endregion

		#region Constants
		#endregion

		#region Helper Types
		#endregion

		#region Members
		#endregion

		#region Properties
		#endregion

		#region Methods
		#endregion

		#region Event Handlers
		#endregion
	}
}