﻿// Ignore Spelling: IRC

namespace IRC.ModuleInterfaces
{
	public interface IModule
	{
		string Name
		{
			get;
		}
	}
}