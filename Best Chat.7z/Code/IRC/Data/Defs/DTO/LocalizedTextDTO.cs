﻿// Ignore Spelling: Defs DTO

namespace BestChat.IRC.Data.Defs.DTO
{
	public record LocalizedTextDTO
	(
		string Lang,
		string Translation
	);
}